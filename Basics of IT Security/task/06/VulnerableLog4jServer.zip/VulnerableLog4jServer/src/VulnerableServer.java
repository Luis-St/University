import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

import org.apache.logging.log4j.*;

public class VulnerableServer {

	private static final Logger logger = LogManager.getLogger(VulnerableServer.class);

	public static void main(String[] args) throws IOException {
		// The default trusturlcodebase of the higher version JDK is false
		System.setProperty("com.sun.jndi.ldap.object.trustURLCodebase", "true");
		
		ServerSocket serverSocket = new ServerSocket(8080);
		while (true) {
			try {
				System.out.println("Server bereit...");
				Socket clientSocket = serverSocket.accept();
				handleRequest(clientSocket);
			} catch (Exception e) {
				// Fehler ignorieren
			}
		}

	}

	private static void handleRequest(Socket clientSocket) throws IOException {
		
		String requestedRessource = getRequestedRessource(clientSocket);
		
		//In produktiven Servern: Protokollierung des Zugriffs
		logger.always().log("Angefragte Resource: " + requestedRessource);
		
		//Antwort senden
		byte[] response = createHTMLResponse(requestedRessource).getBytes();
		clientSocket.getOutputStream().write(response);
		clientSocket.close();
	}
	
	private static String getRequestedRessource(Socket socket) throws IOException {
		// InputStream holen, um Anfrage zu lesen
		InputStreamReader isr = new InputStreamReader(socket.getInputStream());
		BufferedReader br = new BufferedReader(isr);
		// Erste Zeile (GET <Resource> <Protokoll>) Resource auslesen
		String requestedRessource = br.readLine().split(" ")[1];
		// Angabe der Resource ist URL-Encoded. Dekodieren
		requestedRessource = URLDecoder.decode(requestedRessource, StandardCharsets.UTF_8);
		return requestedRessource;
	}
	
	private static String createHTMLResponse(String ressource) {
		StringBuilder sb = new StringBuilder();
		sb.append("HTTP/1.0 200 OK\r\n");
		sb.append("Content-Type: text/html\r\n");
		sb.append("\r\n");
		sb.append("<html><body>Angefragte Resource: ");
		sb.append(ressource);
		sb.append("</body></html>");
		return sb.toString();
	}

}
